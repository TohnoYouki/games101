using System.Dynamic;
using UnityEngine;
using UnityEngine.Rendering;

public partial class PostFxStack
{
    public enum Pass {
        BLOOMCOMBINE, BLOOMHORIZONTAL, BLOOMPREFILTER, BLOOMVERTICAL, COPY
    }

    private const int maxBloomPyramidLevels = 16;

    private int[] bloomIDs = new int[maxBloomPyramidLevels * 2];

    private const string bufferName = "Post FX";

    private CommandBuffer buffer = 
        new CommandBuffer { name = bufferName };

    private Camera camera;

    private ScriptableRenderContext context;

    private PostFXSettings settings;

    private static int bloomBicubicUpsamplingID = 
        Shader.PropertyToID("_BloomBicubicUpsampling");

    private static int bloomIntensityID = 
        Shader.PropertyToID("_BloomIntensity");

    private static int bloomThresholdID = 
        Shader.PropertyToID("_BloomThreshold");

    private static int fxSourceID = Shader.PropertyToID("_PostFXSource");

    private static int fxSource2ID = Shader.PropertyToID("_PostFXSource2");

    public bool IsActive => settings != null;

    public PostFxStack() {
        for (int i = 0; i < maxBloomPyramidLevels * 2; i++) {
            bloomIDs[i] = Shader.PropertyToID("_BloomPyramid" + i);
        }
    }

    public void Setup(ScriptableRenderContext context, 
        Camera camera, PostFXSettings settings) {
        this.camera = camera;
        this.context = context;
        this.settings = camera.cameraType <= CameraType.SceneView ? settings : null;
        ApplySceneViewState();
    }

    private void Draw(RenderTargetIdentifier source, RenderTargetIdentifier target,
                      Pass pass) {
        buffer.SetGlobalTexture(fxSourceID, source);
        buffer.SetRenderTarget(target, 
            RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store);
        buffer.DrawProcedural(
            Matrix4x4.identity, settings.Material, 
            (int)pass, MeshTopology.Triangles, 3);
    }

    private void Bloom(int sourceID) {
        buffer.BeginSample("Bloom");

        buffer.SetGlobalFloat(bloomBicubicUpsamplingID, settings.Bloom.bicubicUpsampling ? 1.0f : 0.0f);
        buffer.SetGlobalFloat(bloomIntensityID, 1.0f);
        buffer.SetGlobalVector(bloomThresholdID, 
            new Vector4(Mathf.GammaToLinearSpace(settings.Bloom.threshold), 
            settings.Bloom.thresholdKnee));

        int width = camera.pixelWidth / 2, height = camera.pixelHeight / 2, iter = 0;
        for (iter = 0; iter < settings.Bloom.maxIterations; iter++) {
            if (width <= settings.Bloom.downscaleLimit 
             || height <= settings.Bloom.downscaleLimit) { break; }
            buffer.GetTemporaryRT(
                bloomIDs[2 * iter + 1], width, height, 0,
                FilterMode.Bilinear, RenderTextureFormat.Default);
            buffer.GetTemporaryRT(
                bloomIDs[2 * iter], width, height, 0, 
                FilterMode.Bilinear, RenderTextureFormat.Default);
            if (iter == 0) {
                Draw(sourceID, bloomIDs[1], Pass.BLOOMPREFILTER);
            } else {
                Draw(bloomIDs[2 * iter - 1], bloomIDs[2 * iter], Pass.BLOOMHORIZONTAL);
                Draw(bloomIDs[2 * iter], bloomIDs[2 * iter + 1], Pass.BLOOMVERTICAL);
            }
            width /= 2;
            height /= 2;
        }

        if (iter == 0) {
            Draw(sourceID, BuiltinRenderTextureType.CameraTarget, Pass.COPY);
        } else {
            for (int i = iter - 1; i >= 1; i--) {
                buffer.SetGlobalTexture(fxSource2ID, bloomIDs[2 * i - 1]);
                Draw(i >= iter - 1 ? bloomIDs[2 * i + 1] : bloomIDs[2 * i], 
                    bloomIDs[2 * i - 2], Pass.BLOOMCOMBINE);
            }
            buffer.SetGlobalFloat(bloomIntensityID, settings.Bloom.intensity);
            buffer.SetGlobalTexture(fxSource2ID, sourceID);
            Draw(iter == 1 ? bloomIDs[1] : bloomIDs[0], 
                BuiltinRenderTextureType.CameraTarget, Pass.BLOOMCOMBINE);
        }

        for (iter -= 1; iter >= 0; iter--) {
            buffer.ReleaseTemporaryRT(bloomIDs[2 * iter]);
            buffer.ReleaseTemporaryRT(bloomIDs[2 * iter + 1]);
        }
        buffer.EndSample("Bloom");
    }

    public void Render(int sourceID) {
        Bloom(sourceID);
        context.ExecuteCommandBuffer(buffer);
        buffer.Clear();
    }
}
