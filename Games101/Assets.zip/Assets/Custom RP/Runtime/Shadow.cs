using UnityEngine;
using UnityEngine.Rendering;

public class Shadow {
    
    private const string bufferName = "Shadows";
    
    private CommandBuffer buffer = new CommandBuffer{ name = bufferName };

    private bool useShadowMask = false;
    
    private ScriptableRenderContext context;
    
    private CullingResults cullingResults;
    
    private ShadowSettings shadowSettings;
    
    private const int maxShadowedDirectionalLightCount = 4;

    private const int maxDirectionalLightCascadeCount = 4;
    
    private struct ShadowedDirectionalLight {
        public int visibleLightIndex;
        public float slopeScaleBias;
        public float nearPlaneOffset;
    }
    
    private int shadowedDirectionalLightCount = 0;
    
    private ShadowedDirectionalLight[] shadowedDirectionalLights = 
        new ShadowedDirectionalLight[maxShadowedDirectionalLightCount];

    private static int dirShadowAtlasId = 
        Shader.PropertyToID("_DirectionalShadowAtlas");

    private static int dirShadowMatricesId = 
        Shader.PropertyToID("_DirectionalShadowMatrices");

    private static int dirShadowCascadeCountId =
        Shader.PropertyToID("_DirectionalShadowCascadeCount");

    private static int dirShadowCascadeCullingSpheresId =
        Shader.PropertyToID("_DirectionalShadowCascadeCullingSpheres");

    private static int dirShadowCascadeDataid = 
        Shader.PropertyToID("_DirectionalShadowCascadeData");

    private static int dirShadowAtlasSizeID = 
        Shader.PropertyToID("_DirectionalShadowAtlasSize");

    private static int dirShadowFadeId = 
        Shader.PropertyToID("_DirectionalShadowFade");

    private static string[] dirShadowPcfFilterKeywords = {
        "_DIRECTIONAL_PCF3", "_DIRECTIONAL_PCF5", "_DIRECTIONAL_PCF7"
    };

    private static string[] dirShadowCascadeBlendKeywords = {
        "_CASCADE_BLEND_DITHER", "_CASCADE_BLEND_SOFT"
    };

    private static string[] shadowMaskKeywords = {
        "_SHADOW_MASK_ALWAYS", "_SHADOW_MASK_DISTANCE"
    };

    private Vector4[] dirShadowCascadeCullingSpheres = 
        new Vector4[maxDirectionalLightCascadeCount];

    private Vector4[] dirShadowCascadeDatas = 
        new Vector4[maxDirectionalLightCascadeCount];
    
    private Matrix4x4[] dirShadowMatrices = new Matrix4x4[
        maxShadowedDirectionalLightCount * maxDirectionalLightCascadeCount];

	private void ExecuteBuffer () {
		context.ExecuteCommandBuffer(buffer);
		buffer.Clear();
	}
    
    public void Setup(ScriptableRenderContext context,
        CullingResults cullingResults, ShadowSettings shadowSettings) {
        this.context = context;
        this.cullingResults = cullingResults;
        this.shadowSettings = shadowSettings;
        this.shadowedDirectionalLightCount = 0;
    }
    
    public Vector4 ReserveDirectionalShadows(Light light, int visibleLightIndex) {
        if (shadowedDirectionalLightCount < maxShadowedDirectionalLightCount &&
            light.shadows != LightShadows.None && light.shadowStrength > 0) {
            float maskChannel = -1f;
            LightBakingOutput bakingOutput = light.bakingOutput;
            if (bakingOutput.lightmapBakeType == LightmapBakeType.Mixed &&
                bakingOutput.mixedLightingMode == MixedLightingMode.Shadowmask) {
                useShadowMask = true;
                maskChannel = bakingOutput.occlusionMaskChannel;
            }
            if (!cullingResults.GetShadowCasterBounds(
                    visibleLightIndex, out Bounds bounds)) {
                return new Vector4(-light.shadowStrength, 0f, 0f, maskChannel);
            }

            shadowedDirectionalLights[shadowedDirectionalLightCount] = 
                new ShadowedDirectionalLight { 
                    visibleLightIndex = visibleLightIndex,
                    slopeScaleBias = light.shadowBias,
                    nearPlaneOffset = light.shadowNearPlane
                };
            int index = shadowedDirectionalLightCount * shadowSettings.directional.cascadeCount;
            shadowedDirectionalLightCount++;
            return new Vector4(light.shadowStrength, index, light.shadowNormalBias, maskChannel);
        }
        return new Vector4(0.0f, 0.0f, 0.0f, -1f);
    }

    private Rect GetShadowMapRect(int index) {
        int count = shadowedDirectionalLightCount * shadowSettings.directional.cascadeCount;
        int split = count <= 1 ? 1 : (count <= 4 ? 2 : 4);
        int size = (int)shadowSettings.directional.atlasSize / split;
        Vector2 offset = new Vector2(index % split, index / split);
        return new Rect(offset.x * size, offset.y * size, size, size);
    }

    private Matrix4x4 GetShadowMapMatrix(
        Matrix4x4 viewMatrix, Matrix4x4 projMatrix, Rect rect) {
        Matrix4x4 m = projMatrix * viewMatrix;
        if (SystemInfo.usesReversedZBuffer) {
            m.m20 = -m.m20;
            m.m21 = -m.m21;
            m.m22 = -m.m22;
            m.m23 = -m.m23;
        }
        int size = (int)shadowSettings.directional.atlasSize;
        Vector2 scale = new Vector2(rect.width / size, rect.height / size);
        Vector2 offset = new Vector2(rect.x / size, rect.y / size);
		m.m00 = 0.5f * (m.m00 + m.m30) * scale.x + offset.x * m.m30;
		m.m01 = 0.5f * (m.m01 + m.m31) * scale.x + offset.x * m.m31;
		m.m02 = 0.5f * (m.m02 + m.m32) * scale.x + offset.x * m.m32;
		m.m03 = 0.5f * (m.m03 + m.m33) * scale.x + offset.x * m.m33;
		m.m10 = 0.5f * (m.m10 + m.m30) * scale.y + offset.y * m.m30;
		m.m11 = 0.5f * (m.m11 + m.m31) * scale.y + offset.y * m.m31;
		m.m12 = 0.5f * (m.m12 + m.m32) * scale.y + offset.y * m.m32;
		m.m13 = 0.5f * (m.m13 + m.m33) * scale.y + offset.y * m.m33;
		m.m20 = 0.5f * (m.m20 + m.m30);
		m.m21 = 0.5f * (m.m21 + m.m31);
		m.m22 = 0.5f * (m.m22 + m.m32);
		m.m23 = 0.5f * (m.m23 + m.m33);
        return m;  
    }

    private void SetDirectionalShadowCascadeData(int index, Vector4 sphere, int resolution) {
        float texelSize = 2f * sphere.w / resolution;
        texelSize *= ((float)shadowSettings.directional.filterMode + 1);
        sphere.w -= texelSize;
        sphere.w *= sphere.w;
        dirShadowCascadeCullingSpheres[index] = sphere;
        dirShadowCascadeDatas[index] = new Vector4(
            1f / sphere.w, texelSize * Mathf.Sqrt(2)
        );
    }

    private void RenderDirectionalShadows(int index) {
        var light = shadowedDirectionalLights[index];
        int cascade = shadowSettings.directional.cascadeCount;
        Vector3 ratio = shadowSettings.directional.CascadeRatios;

        for (int i = 0; i < cascade; i++) {
            int subIndex = index * cascade + i;
            Rect rect = GetShadowMapRect(subIndex);
            int resolution = (int)Mathf.Min(rect.width, rect.height);
            cullingResults.ComputeDirectionalShadowMatricesAndCullingPrimitives(
                light.visibleLightIndex, i, cascade, ratio, resolution, 
                light.nearPlaneOffset, out Matrix4x4 viewMatrix, 
                out Matrix4x4 projMatrix, out ShadowSplitData splitData
            );
            splitData.shadowCascadeBlendCullingFactor = 
                Mathf.Max(0f, 0.8f - shadowSettings.directional.cascadeFade);
            SetDirectionalShadowCascadeData(i, splitData.cullingSphere, resolution);
            buffer.SetViewport(rect);
            buffer.SetViewProjectionMatrices(viewMatrix, projMatrix);
            buffer.SetGlobalDepthBias(0f, light.slopeScaleBias);
            ExecuteBuffer();
            ShadowDrawingSettings settings = new ShadowDrawingSettings (
                cullingResults, light.visibleLightIndex
            ) { splitData = splitData };
            context.DrawShadows(ref settings);
            buffer.SetGlobalDepthBias(0f, 0f);
            ExecuteBuffer();
            dirShadowMatrices[subIndex] = 
                GetShadowMapMatrix(viewMatrix, projMatrix, rect);
        }
    }

    private void SelectShaderMultiCompile(string[] keywords, int index) {
        for (int i = 0; i < keywords.Length; i++) {
            if (i == index) {
                buffer.EnableShaderKeyword(keywords[i]);
            } else {
                buffer.DisableShaderKeyword(keywords[i]);
            }
        }
    }

    private void RenderDirectionalShadows() {
        int atlasSize = (int)shadowSettings.directional.atlasSize;
        buffer.GetTemporaryRT(
            dirShadowAtlasId, atlasSize, atlasSize, 32,
            FilterMode.Bilinear, RenderTextureFormat.Shadowmap);
        buffer.SetRenderTarget(dirShadowAtlasId, 
            RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store);
        buffer.ClearRenderTarget(true, false, Color.clear);
        buffer.BeginSample(bufferName);
        ExecuteBuffer();
        for(int i = 0; i < shadowedDirectionalLightCount; i++) {
            RenderDirectionalShadows(i);
        }
        buffer.SetGlobalInt(
            dirShadowCascadeCountId, shadowSettings.directional.cascadeCount);
        buffer.SetGlobalVector(dirShadowFadeId, new Vector4(
            1 / shadowSettings.distanceFade, 1 / shadowSettings.maxDistance,
            1 / (1 - Mathf.Pow(1 - shadowSettings.directional.cascadeFade, 2)), 0.0f));
        buffer.SetGlobalVectorArray(
            dirShadowCascadeCullingSpheresId, dirShadowCascadeCullingSpheres);
        buffer.SetGlobalVectorArray(
            dirShadowCascadeDataid, dirShadowCascadeDatas);
        buffer.SetGlobalMatrixArray(dirShadowMatricesId, dirShadowMatrices);
        buffer.SetGlobalVector(
            dirShadowAtlasSizeID, new Vector4(atlasSize, 1.0f / atlasSize));
        SelectShaderMultiCompile(
            dirShadowPcfFilterKeywords, (int)shadowSettings.directional.filterMode - 1);
        SelectShaderMultiCompile(
            dirShadowCascadeBlendKeywords, (int)shadowSettings.directional.cascadeBlendMode - 1);
        buffer.EndSample(bufferName);
        ExecuteBuffer();
    }

    public void Render() {
        buffer.BeginSample(bufferName);
        SelectShaderMultiCompile(shadowMaskKeywords, 
            useShadowMask ? (QualitySettings.shadowmaskMode 
            == ShadowmaskMode.Shadowmask ? 0 : 1) : -1);
        buffer.EndSample(bufferName);
        ExecuteBuffer();

        if (shadowedDirectionalLightCount > 0) {
            RenderDirectionalShadows();
        } else {
            buffer.GetTemporaryRT(
                dirShadowAtlasId, 1, 1, 32, 
                FilterMode.Bilinear, RenderTextureFormat.Shadowmap);
            ExecuteBuffer();
        }
    }

    public void Cleanup() {
        buffer.ReleaseTemporaryRT(dirShadowAtlasId);
        ExecuteBuffer();
    }
}
