using UnityEngine;
using Unity.Collections;
using UnityEngine.Rendering;

public class Lighting {

    private const string bufferName = "Lighting";
    
    private CommandBuffer buffer = new CommandBuffer { name = bufferName };
    
    private CullingResults cullingResults;
    
    private Shadow shadows = new Shadow();
    
    private const int maxDirectionalLightCount = 4;
    
    private Vector4[] dirLightColors = 
        new Vector4[maxDirectionalLightCount];
    
    private Vector4[] dirLightDirections = 
        new Vector4[maxDirectionalLightCount];

    private Vector4[] dirLightShadowDatas = 
        new Vector4[maxDirectionalLightCount];
    
    private static int dirLightCountId = 
        Shader.PropertyToID("_DirectionalLightCount");
    
    private static int dirLightColorId = 
        Shader.PropertyToID("_DirectionalLightColor");
    
    private static int dirLightDirectionId = 
        Shader.PropertyToID("_DirectionalLightDirection");

    private static int dirLightShadowDataId = 
        Shader.PropertyToID("_DirectionalLightShadowData");
    
    private void SetupDirectionalLight(int index, ref VisibleLight light) {
        dirLightColors[index] = light.finalColor;
        dirLightDirections[index] = -light.localToWorldMatrix.GetColumn(2);
        dirLightShadowDatas[index] = shadows.ReserveDirectionalShadows(light.light, index);
    }
    
    private void SetupLights() {
        NativeArray<VisibleLight> visibleLights = cullingResults.visibleLights;
        int dirLightCount = 0;
        for (int i = 0; i < visibleLights.Length; i++) {
            VisibleLight light = visibleLights[i]; 
            if (light.lightType == LightType.Directional) {
                SetupDirectionalLight(dirLightCount++, ref light);
                if (dirLightCount > maxDirectionalLightCount) { break; }
            }
        }
        buffer.SetGlobalInt(dirLightCountId, dirLightCount);
        buffer.SetGlobalVectorArray(dirLightColorId, dirLightColors);
        buffer.SetGlobalVectorArray(dirLightDirectionId, dirLightDirections);
        buffer.SetGlobalVectorArray(dirLightShadowDataId, dirLightShadowDatas);
    }
    
    public void Setup(ScriptableRenderContext context, 
        CullingResults cullingResults, ShadowSettings shadowSettings) {
        this.cullingResults = cullingResults;
        buffer.BeginSample(bufferName);
        shadows.Setup(context, cullingResults, shadowSettings);
        SetupLights();
        shadows.Render();
        buffer.EndSample(bufferName);
        context.ExecuteCommandBuffer(buffer);
        buffer.Clear();
    }

    public void Cleanup() {
        shadows.Cleanup();
    }
}
