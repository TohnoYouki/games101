using UnityEngine;
using UnityEngine.Rendering;

public partial class CameraRenderer {

    private const string bufferName = "Render Camera";

    private CommandBuffer buffer = new CommandBuffer {
        name = bufferName
    };

    private Camera camera;

    private ScriptableRenderContext context;

    private CullingResults cullingResult;

    private Lighting lighting = new Lighting();

    private static ShaderTagId unlitShaderTagId = 
        new ShaderTagId("SRPDefaultUnlit");

    private static ShaderTagId litShaderTagId = 
        new ShaderTagId("CustomLit");

	private void ExecuteBuffer () {
		context.ExecuteCommandBuffer(buffer);
		buffer.Clear();
	}

    private bool Cull(float maxShadowDistance) {
        ScriptableCullingParameters param;
        if (camera.TryGetCullingParameters(out param)) {
            param.shadowDistance = Mathf.Min(maxShadowDistance, camera.farClipPlane);
            cullingResult = context.Cull(ref param);
            return true;
        }
        return false;
    }

    private void Setup() {
        context.SetupCameraProperties(camera);
        CameraClearFlags flags = camera.clearFlags;
        buffer.ClearRenderTarget(flags <= CameraClearFlags.Depth, 
                                 flags == CameraClearFlags.Color, 
                                 flags == CameraClearFlags.Color ? 
                                 camera.backgroundColor.linear : Color.clear);
    }

    private void DrawVisibleGeometry(bool useDynamicBatching, bool useGPUInstancing) {
        var sortSetting = new SortingSettings(camera) {
            criteria = SortingCriteria.CommonOpaque
        };
        var drawingSetting = new DrawingSettings(unlitShaderTagId, sortSetting) {
            enableDynamicBatching = useDynamicBatching,
            enableInstancing = useGPUInstancing,
            perObjectData = PerObjectData.Lightmaps 
                          | PerObjectData.LightProbe | PerObjectData.LightProbeProxyVolume
        };
        drawingSetting.SetShaderPassName(1, litShaderTagId);

        var filteringSetting = new FilteringSettings(RenderQueueRange.opaque);
        context.DrawRenderers(
            cullingResult, ref drawingSetting, ref filteringSetting);

        context.DrawSkybox(camera);

        sortSetting.criteria = SortingCriteria.CommonTransparent;
        filteringSetting.renderQueueRange = RenderQueueRange.transparent;
        context.DrawRenderers(
            cullingResult, ref drawingSetting, ref filteringSetting);
    }
    
    public void Render(ScriptableRenderContext context, Camera camera,
                       bool useDynamicBatching, bool useGPUInstancing,
                       ShadowSettings shadowSettings) {
        this.camera = camera;
        this.context = context;
        PrepareForSceneWindow();
        if (!Cull(shadowSettings.maxDistance)) { return; }

        buffer.BeginSample(bufferName);
        ExecuteBuffer();
        lighting.Setup(context, cullingResult, shadowSettings);
        buffer.EndSample(bufferName);

        Setup();
        buffer.BeginSample(bufferName);
        ExecuteBuffer();
        DrawVisibleGeometry(useDynamicBatching, useGPUInstancing);
        DrawUnsupportedShaders();
        DrawGizmos();
        lighting.Cleanup();
        buffer.EndSample(bufferName);
        ExecuteBuffer();
        context.Submit();
    }
}
